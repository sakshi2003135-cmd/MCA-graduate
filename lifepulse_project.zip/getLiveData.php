<?php
header('Content-Type: application/json');
$conn = new mysqli("localhost", "root", "", "lifepulse");
$result = $conn->query("SELECT * FROM health_data ORDER BY timestamp DESC LIMIT 10");

$data = [];
while ($row = $result->fetch_assoc()) {
  $data[] = $row;
}
echo json_encode(array_reverse($data));
$conn->close();
?>