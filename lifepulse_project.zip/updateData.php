<?php
$data = json_decode(file_get_contents("php://input"), true);
$pulse = $data['pulse'];
$oxygen = $data['oxygen'];

$conn = new mysqli("localhost", "root", "", "lifepulse");
$conn->query("INSERT INTO health_data (pulse, oxygen) VALUES ($pulse, $oxygen)");
$conn->close();
?>